package com.example.demo.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class BookRoomEntity
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name="user_mail")
	private String userEmail;
	
	@Column(name="room_id")
	private int roomId;
	
	@Column(name="cost")
	private int cost;
	
	@Column (name="payment_Method")
	private String paymentMethod;
	
	@Column (name="debitCard_Number")
	private long debitCardNumber;
	
	@Column (name="cardWoner_Name")
	private String cardWonerName;
	
	@Column (name="cvv_no")
	private int cvv;
	
	@Column (name="Month")
	private int month;
	
	@Column (name="Year")
	private int year;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public int getCost() 
	{
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public long getDebitCardNumber() {
		return debitCardNumber;
	}

	public void setDebitCardNumber(long debitCardNumber) {
		this.debitCardNumber = debitCardNumber;
	}

	public String getCardWonerName() {
		return cardWonerName;
	}

	public void setCardWonerName(String cardWonerName) {
		this.cardWonerName = cardWonerName;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankBranch() {
		return bankBranch;
	}

	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}

	public String getBankAccountHolderName() {
		return bankAccountHolderName;
	}

	public void setBankAccountHolderName(String bankAccountHolderName) {
		this.bankAccountHolderName = bankAccountHolderName;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getUpi() {
		return upi;
	}

	public void setUpi(int upi) {
		this.upi = upi;
	}

	public String getGooglePayUserName() {
		return googlePayUserName;
	}

	public void setGooglePayUserName(String googlePayUserName) {
		this.googlePayUserName = googlePayUserName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "BookRoomEntity [id=" + id + ", userEmail=" + userEmail + ", roomId=" + roomId + ", cost=" + cost
				+ ", paymentMethod=" + paymentMethod + ", debitCardNumber=" + debitCardNumber + ", cardWonerName="
				+ cardWonerName + ", cvv=" + cvv + ", month=" + month + ", year=" + year + ", bankName=" + bankName
				+ ", bankBranch=" + bankBranch + ", bankAccountHolderName=" + bankAccountHolderName + ", accountNumber="
				+ accountNumber + ", upi=" + upi + ", googlePayUserName=" + googlePayUserName + ", date=" + date + "]";
	}

	@Column (name="bank_Name")
	private String bankName;
	
	@Column (name="bank_Branch")
	private String bankBranch;
	
	@Column (name="bankAccountHolder_Name")
	private String bankAccountHolderName;
	
	@Column (name="account_Number")
	private long accountNumber;
	
	@Column (name="upi_id")
	private int upi;
	
	public BookRoomEntity(long id, String userEmail, int roomId, int cost, String paymentMethod, long debitCardNumber,
			String cardWonerName, int cvv, int month, int year, String bankName, String bankBranch,
			String bankAccountHolderName, long accountNumber, int upi, String googlePayUserName, String date) {
		super();
		this.id = id;
		this.userEmail = userEmail;
		this.roomId = roomId;
		this.cost = cost;
		this.paymentMethod = paymentMethod;
		this.debitCardNumber = debitCardNumber;
		this.cardWonerName = cardWonerName;
		this.cvv = cvv;
		this.month = month;
		this.year = year;
		this.bankName = bankName;
		this.bankBranch = bankBranch;
		this.bankAccountHolderName = bankAccountHolderName;
		this.accountNumber = accountNumber;
		this.upi = upi;
		this.googlePayUserName = googlePayUserName;
		this.date = date;
	}

	public BookRoomEntity() {
		super();
	}

	@Column (name="googlePayUser_Name")
	private String googlePayUserName;
	
	@Column (name="Date")
	private String date;
	
	

}
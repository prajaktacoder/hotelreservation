package com.example.demo.entity;


import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class Feedback {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column
	private String userEmail;
	
	@Column
	private long roomId;
	
//	@Column
//	private long feedbackId;
//	

	@Column
	private String serviceRating;
	
	@Column
	private String comments;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getRoomId() {
		return roomId;
	}

	public void setRoomId(long roomId) {
		this.roomId = roomId;
	}

//	public long getFeedbackId() {
//		return feedbackId;
//	}
//
//	public void setFeedbackId(long feedbackId) {
//		this.feedbackId = feedbackId;
//	}

	public String getServiceRating() {
		return serviceRating;
	}

	public void setServiceRating(String serviceRating) {
		this.serviceRating = serviceRating;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Feedback [id=" + id + ", userEmail=" + userEmail + ", roomId=" + roomId + ", serviceRating=" + serviceRating + ", comments=" + comments + "]";
	}

	public Feedback() {
		super();
	}
	

	
}